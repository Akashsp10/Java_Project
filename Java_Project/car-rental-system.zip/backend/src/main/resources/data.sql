INSERT INTO CAR (id, make, model, plate, price_per_day, available) VALUES (1,'Toyota','Corolla','ABC-123',50.00,TRUE);
INSERT INTO CAR (id, make, model, plate, price_per_day, available) VALUES (2,'Honda','Civic','DEF-456',60.00,TRUE);
INSERT INTO CAR (id, make, model, plate, price_per_day, available) VALUES (3,'Ford','Focus','GHI-789',45.00,TRUE);
